# Deploy Keras Model with Flask as Web App in 10 Minutes

效果图：

![image](https://github.com/Chris-K2/magical_animal_classifier/assets/119746828/3cb9c27f-3ecb-465e-a67c-1eb3fea24f2a)
